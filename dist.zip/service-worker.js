/**
 * Copyright 2016 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
*/

// DO NOT EDIT THIS GENERATED OUTPUT DIRECTLY!
// This file should be overwritten as part of your build process.
// If you need to extend the behavior of the generated service worker, the best approach is to write
// additional code and include it using the importScripts option:
//   https://github.com/GoogleChrome/sw-precache#importscripts-arraystring
//
// Alternatively, it's possible to make changes to the underlying template file and then use that as the
// new base for generating output, via the templateFilePath option:
//   https://github.com/GoogleChrome/sw-precache#templatefilepath-string
//
// If you go that route, make sure that whenever you update your sw-precache dependency, you reconcile any
// changes made to this original template file with your modified copy.

// This generated service worker JavaScript will precache your site's resources.
// The code needs to be saved in a .js file at the top-level of your site, and registered
// from your pages in order to be used. See
// https://github.com/googlechrome/sw-precache/blob/master/demo/app/js/service-worker-registration.js
// for an example of how you can register this script and handle various service worker events.

/* eslint-env worker, serviceworker */
/* eslint-disable indent, no-unused-vars, no-multiple-empty-lines, max-nested-callbacks, space-before-function-paren, quotes, comma-spacing */
'use strict';

var precacheConfig = [["css/agency.css","625900980d2043653beb8789dbf33999"],["css/bootstrap.min.css","f6eca28ac7c5ac20f3af65c717f8f8b0"],["css/print.css","55baefa370daa9cf57038eb8677fde02"],["font-awesome/css/font-awesome.min.css","feda974a77ea5783b8be673f142b7c88"],["font-awesome/fonts/fontawesome-webfont.eot","7149833697a959306ec3012a8588dcfa"],["font-awesome/fonts/fontawesome-webfont.svg","65bcbc899f379216109acd0b6c494618"],["font-awesome/fonts/fontawesome-webfont.ttf","c4668ed2440df82d3fd2f8be9d31d07d"],["font-awesome/fonts/fontawesome-webfont.woff","d95d6f5d5ab7cfefd09651800b69bd54"],["fonts/glyphicons-halflings-regular.eot","f4769f9bdb7466be65088239c12046d1"],["fonts/glyphicons-halflings-regular.svg","89889688147bd7575d6327160d64e760"],["fonts/glyphicons-halflings-regular.ttf","e18bbf611f2a2e43afc071aa2f4e1512"],["fonts/glyphicons-halflings-regular.woff","fa2772327f55d8198301fdb8bcfc8158"],["img/about/study.png","29ab41ad7e192646209aa8ab576d9090"],["img/about/work.png","2aae53efb5b6fbe534b0444d64c79a11"],["img/bu_profilePic.png","b59fa133ec3013cb7af5d6f3e1769e5c"],["img/certificates/angular2_complete.png","47902eda57d95781bfea7382f9b6fef4"],["img/certificates/angular2_complete_crt.png","f45eb8f5d76d65263c7c11c6f040c378"],["img/certificates/angular2_ground_up.png","9b0c428217d42631b1206ecb2c65093a"],["img/certificates/angular2_ground_up_crt.jpg","4df8ece34088bbc443dbdc248dc0c162"],["img/certificates/angular2_nodejs.png","1c4beee14693f757395fb79e5c8d3aa8"],["img/certificates/angular2_nodejs_crt.jpg","8d3331d268362cd78c192ab1f9cf0dd9"],["img/certificates/angular2_theory_prac.png","6fa8c1b8e4b4c601926074a8df4a5bf8"],["img/certificates/angular2_theory_prac_crt.png","f45eb8f5d76d65263c7c11c6f040c378"],["img/certificates/angular2_typescript.png","98f1da8da2e13e1637f6e6ce94053d19"],["img/certificates/angular2_typescript_crt.png","f1d38a46bfe9fec7417ce82e818b6e83"],["img/certificates/complete_nodejs.png","176ba9790eaa97ded2bbc01418a9b85a"],["img/certificates/firebase.png","bf096443f9853c92a35a5cab577ae3d7"],["img/certificates/firebase_crt.jpg","cb8e5db46585085b8d53ba7e1d570eab"],["img/certificates/js_es6.png","6f8ff9f9de853ae62ac98a65a07aaaef"],["img/certificates/js_es6_crt.jpg","b1f47ac42bd6bfac5d5e599ddfcdf094"],["img/certificates/js_weird_parts.png","781a3a4d8ff97331b9e33eac956a9b32"],["img/certificates/js_weird_parts_crt.jpg","66f0da972273ac25f4f43f5eff160cea"],["img/certificates/react.png","796587d98976d313ee916090db6e578a"],["img/certificates/unity.png","fd7e5ebc49754c534bb0fea9070f844e"],["img/header-bg.jpg","00f66c1866a7dff607ef3ab61049d69d"],["img/map-image.png","d56cde1c8e82594e59bf54fe741d7299"],["img/portfolio/dreams-preview.png","a07ecf093399802e3dd701951a09f66a"],["img/portfolio/dreams.png","8fdd14e87fe0499481c19bed66e46934"],["img/portfolio/escape-preview.png","ef62908d868f04fb0aaef8e1b68b6cb3"],["img/portfolio/escape.png","752b941c47d58778d88913495c7cb461"],["img/portfolio/golden-preview.png","f2ba4eff72f5c2fd27733a714d03ad02"],["img/portfolio/golden.png","3e88b5bcdb1e129ceb04f2a7eb213dda"],["img/portfolio/roundicons-free.png","1c0d605a5040ce1d299e91fc0c3f0669"],["img/portfolio/roundicons.png","fa64225d5cdeea55df3da34333b025a8"],["img/portfolio/startup-framework-preview.png","6a4fc86c51c2d07336132845e1a39c18"],["img/portfolio/startup-framework.png","982391727b746e5fc5d68d87c71f3581"],["img/portfolio/swyserdev.png","5105f7e7628209300fafd63157c0852b"],["img/portfolio/treehouse-preview.png","30f344abaa6458883350eb39f20edf8f"],["img/portfolio/treehouse.png","685f3bd1e62aaf1d2a1afb401560d06e"],["img/profilePic.png","c7d53ff36cf0bdde366e7078425d93e7"],["index.html","cf8d7ed6590a43d503aaec15119f1e22"],["js/agency.js","4521f202b916f9395797faad55af7976"],["js/bootstrap.min.js","9cdd0a24dd301a08c85afcc73e8ac1ea"],["js/cbpAnimatedHeader.min.js","2b4ccdb202092d1ae3515134d9ba8d8f"],["js/classie.js","f90b5b618f59cd93dd5340e74afd9971"],["js/contact_me.js","69ca79aed03f40ef40d33e7a1ccb19ed"],["js/jqBootstrapValidation.js","05a784305e87bba0de4708b6eea0c26e"],["js/jquery.min.js","adcc4d0c3a34f2bf780e115939292153"]];
var cacheName = 'sw-precache-v3--' + (self.registration ? self.registration.scope : '');


var ignoreUrlParametersMatching = [/^utm_/];



var addDirectoryIndex = function (originalUrl, index) {
    var url = new URL(originalUrl);
    if (url.pathname.slice(-1) === '/') {
      url.pathname += index;
    }
    return url.toString();
  };

var cleanResponse = function (originalResponse) {
    // If this is not a redirected response, then we don't have to do anything.
    if (!originalResponse.redirected) {
      return Promise.resolve(originalResponse);
    }

    // Firefox 50 and below doesn't support the Response.body stream, so we may
    // need to read the entire body to memory as a Blob.
    var bodyPromise = 'body' in originalResponse ?
      Promise.resolve(originalResponse.body) :
      originalResponse.blob();

    return bodyPromise.then(function(body) {
      // new Response() is happy when passed either a stream or a Blob.
      return new Response(body, {
        headers: originalResponse.headers,
        status: originalResponse.status,
        statusText: originalResponse.statusText
      });
    });
  };

var createCacheKey = function (originalUrl, paramName, paramValue,
                           dontCacheBustUrlsMatching) {
    // Create a new URL object to avoid modifying originalUrl.
    var url = new URL(originalUrl);

    // If dontCacheBustUrlsMatching is not set, or if we don't have a match,
    // then add in the extra cache-busting URL parameter.
    if (!dontCacheBustUrlsMatching ||
        !(url.pathname.match(dontCacheBustUrlsMatching))) {
      url.search += (url.search ? '&' : '') +
        encodeURIComponent(paramName) + '=' + encodeURIComponent(paramValue);
    }

    return url.toString();
  };

var isPathWhitelisted = function (whitelist, absoluteUrlString) {
    // If the whitelist is empty, then consider all URLs to be whitelisted.
    if (whitelist.length === 0) {
      return true;
    }

    // Otherwise compare each path regex to the path of the URL passed in.
    var path = (new URL(absoluteUrlString)).pathname;
    return whitelist.some(function(whitelistedPathRegex) {
      return path.match(whitelistedPathRegex);
    });
  };

var stripIgnoredUrlParameters = function (originalUrl,
    ignoreUrlParametersMatching) {
    var url = new URL(originalUrl);

    url.search = url.search.slice(1) // Exclude initial '?'
      .split('&') // Split into an array of 'key=value' strings
      .map(function(kv) {
        return kv.split('='); // Split each 'key=value' string into a [key, value] array
      })
      .filter(function(kv) {
        return ignoreUrlParametersMatching.every(function(ignoredRegex) {
          return !ignoredRegex.test(kv[0]); // Return true iff the key doesn't match any of the regexes.
        });
      })
      .map(function(kv) {
        return kv.join('='); // Join each [key, value] array into a 'key=value' string
      })
      .join('&'); // Join the array of 'key=value' strings into a string with '&' in between each

    return url.toString();
  };


var hashParamName = '_sw-precache';
var urlsToCacheKeys = new Map(
  precacheConfig.map(function(item) {
    var relativeUrl = item[0];
    var hash = item[1];
    var absoluteUrl = new URL(relativeUrl, self.location);
    var cacheKey = createCacheKey(absoluteUrl, hashParamName, hash, false);
    return [absoluteUrl.toString(), cacheKey];
  })
);

function setOfCachedUrls(cache) {
  return cache.keys().then(function(requests) {
    return requests.map(function(request) {
      return request.url;
    });
  }).then(function(urls) {
    return new Set(urls);
  });
}

self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return setOfCachedUrls(cache).then(function(cachedUrls) {
        return Promise.all(
          Array.from(urlsToCacheKeys.values()).map(function(cacheKey) {
            // If we don't have a key matching url in the cache already, add it.
            if (!cachedUrls.has(cacheKey)) {
              var request = new Request(cacheKey, {credentials: 'same-origin'});
              return fetch(request).then(function(response) {
                // Bail out of installation unless we get back a 200 OK for
                // every request.
                if (!response.ok) {
                  throw new Error('Request for ' + cacheKey + ' returned a ' +
                    'response with status ' + response.status);
                }

                return cleanResponse(response).then(function(responseToCache) {
                  return cache.put(cacheKey, responseToCache);
                });
              });
            }
          })
        );
      });
    }).then(function() {
      
      // Force the SW to transition from installing -> active state
      return self.skipWaiting();
      
    })
  );
});

self.addEventListener('activate', function(event) {
  var setOfExpectedUrls = new Set(urlsToCacheKeys.values());

  event.waitUntil(
    caches.open(cacheName).then(function(cache) {
      return cache.keys().then(function(existingRequests) {
        return Promise.all(
          existingRequests.map(function(existingRequest) {
            if (!setOfExpectedUrls.has(existingRequest.url)) {
              return cache.delete(existingRequest);
            }
          })
        );
      });
    }).then(function() {
      
      return self.clients.claim();
      
    })
  );
});


self.addEventListener('fetch', function(event) {
  if (event.request.method === 'GET') {
    // Should we call event.respondWith() inside this fetch event handler?
    // This needs to be determined synchronously, which will give other fetch
    // handlers a chance to handle the request if need be.
    var shouldRespond;

    // First, remove all the ignored parameter and see if we have that URL
    // in our cache. If so, great! shouldRespond will be true.
    var url = stripIgnoredUrlParameters(event.request.url, ignoreUrlParametersMatching);
    shouldRespond = urlsToCacheKeys.has(url);

    // If shouldRespond is false, check again, this time with 'index.html'
    // (or whatever the directoryIndex option is set to) at the end.
    var directoryIndex = 'index.html';
    if (!shouldRespond && directoryIndex) {
      url = addDirectoryIndex(url, directoryIndex);
      shouldRespond = urlsToCacheKeys.has(url);
    }

    // If shouldRespond is still false, check to see if this is a navigation
    // request, and if so, whether the URL matches navigateFallbackWhitelist.
    var navigateFallback = '';
    if (!shouldRespond &&
        navigateFallback &&
        (event.request.mode === 'navigate') &&
        isPathWhitelisted([], event.request.url)) {
      url = new URL(navigateFallback, self.location).toString();
      shouldRespond = urlsToCacheKeys.has(url);
    }

    // If shouldRespond was set to true at any point, then call
    // event.respondWith(), using the appropriate cache key.
    if (shouldRespond) {
      event.respondWith(
        caches.open(cacheName).then(function(cache) {
          return cache.match(urlsToCacheKeys.get(url)).then(function(response) {
            if (response) {
              return response;
            }
            throw Error('The cached response that was expected is missing.');
          });
        }).catch(function(e) {
          // Fall back to just fetch()ing the request if some unexpected error
          // prevented the cached response from being valid.
          console.warn('Couldn\'t serve response for "%s" from cache: %O', event.request.url, e);
          return fetch(event.request);
        })
      );
    }
  }
});







